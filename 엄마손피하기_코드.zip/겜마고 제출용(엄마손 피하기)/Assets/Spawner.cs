using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject fistPrefab;
 
    public float spawnInterval = 0.7f;
    private float timer = 0f;
    public float xRange = 12.0f;
    public float zRange = 5.0f;
    public float spawnY = 12.0f;

    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= spawnInterval)
        {
            SpawnFist();
            timer = 0f;
        }
    }
    void SpawnFist()
    {
        float randomX = Random.Range(-xRange, xRange);
        float randomZ = Random.Range(-zRange, zRange);
        Vector3 spawnPos = new Vector3(randomX, spawnY, randomZ);
        Instantiate(fistPrefab, spawnPos, Quaternion.Euler(450, 90, 90));
    }
}
