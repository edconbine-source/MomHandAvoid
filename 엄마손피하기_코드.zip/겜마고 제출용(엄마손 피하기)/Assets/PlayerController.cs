﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    
    [Header("사운드 설정")]
    public AudioClip punchSound; 
    public AudioClip paperSound; 

    [Header("이동 설정")]
    public float moveSpeed = 8f;
    public float xLimit = 13f; 
    public float zLimit = 5.5f; 
    public float rotationSpeed = 15f; 

    
    void Update()
    {
        
        float hAxis = Input.GetAxisRaw("Horizontal");
        float vAxis = Input.GetAxisRaw("Vertical");

        
        Vector3 moveDirection = new Vector3(hAxis, 0f, vAxis).normalized;

       
        transform.Translate(moveDirection * moveSpeed * Time.deltaTime, Space.World);

        
        if (moveDirection != Vector3.zero)
        {
            
            Quaternion targetRotation = Quaternion.LookRotation(moveDirection);
            
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
        }

        
        Vector3 currentPos = transform.position;
        currentPos.x = Mathf.Clamp(currentPos.x, -xLimit, xLimit);
        currentPos.z = Mathf.Clamp(currentPos.z, -zLimit, zLimit);
        transform.position = currentPos;
    }

    
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Fist"))
        {
            
            if (punchSound != null)
            {
                AudioSource.PlayClipAtPoint(punchSound, transform.position);
            }

            
            GameOverManager gm = FindObjectOfType<GameOverManager>();
            if (gm != null)
            {
                gm.ShowGameOver();
            }

            
            Time.timeScale = 0f;

            
            foreach (Renderer r in GetComponentsInChildren<Renderer>())
            {
                r.enabled = false;
            }
            GetComponent<Collider>().enabled = false;
        }
    }

    
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Coin"))
        {
            
            if (paperSound != null)
            {
                AudioSource.PlayClipAtPoint(paperSound, transform.position);
            }

            
            GameManager gm = FindObjectOfType<GameManager>();
            if (gm != null)
            {
                gm.AddScore(1); 
            }

            
            Destroy(other.gameObject);
        }
    }
}
