using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinSpawner : MonoBehaviour
{
    public GameObject coinPrefab; 
    public float spawnInterval = 3.0f;
    private float timer;

   
    public float minX = -4.0f;
    public float maxX = 4.0f;
    public float minZ = -4.0f;
    public float maxZ = 4.0f;
    
    
   
    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= spawnInterval)
        {
            SpawnCoin();
            timer = 0f;
        }
    }
    void SpawnCoin()
    {
        float randomX = Random.Range(minX, maxX);
        float randomZ = Random.Range(minZ, maxZ);
        Vector3 spawnPos = new Vector3(randomX, 0.5f, randomZ);

        Instantiate(coinPrefab, spawnPos, Quaternion.identity);
    }
}
