using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuManager : MonoBehaviour
{
   
    public void GameStart()
    {
        SceneManager.LoadScene("SampleScene"); 
    }

   
    public void GameQuit()
    {
        Application.Quit();
        Debug.Log("���� ����!"); 
    }
}
