using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public TextMeshProUGUI scoreText; 
    private int score = 0;  

    
    void Start()
    {
        UpdateScoreText();
    }

    
    public void AddScore(int amount)
    {
        score += amount;
        UpdateScoreText();
    }

    
    void UpdateScoreText()
    {
        scoreText.text = "Score : " + score;
    }
}
